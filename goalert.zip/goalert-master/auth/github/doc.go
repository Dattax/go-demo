// Package github implements an auth provider and backend that identifies a user via github account.
package github
