// Package basic implements a simple auth provider and backend that identifies a user via username & password combination.
package basic
