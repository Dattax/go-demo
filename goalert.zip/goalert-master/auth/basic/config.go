package basic

// Config configures the basic auth provider
type Config struct {
}
