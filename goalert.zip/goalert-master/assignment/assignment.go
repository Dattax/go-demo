package assignment

type Assignment interface {
	Source
	Target
}
