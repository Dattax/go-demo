/* package assignment handles updating and resolving entity assignments


Everything from Alerts down must resolve to one or more contact methods in the end.
*/

package assignment
