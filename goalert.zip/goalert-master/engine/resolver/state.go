package resolver

import "time"

type State struct {
	Time    time.Time
	AlertID int
}
