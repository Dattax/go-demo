package engine

import (
	"github.com/target/goalert/alert"
	alertlog "github.com/target/goalert/alert/log"
	"github.com/target/goalert/config"
	"github.com/target/goalert/keyring"
	"github.com/target/goalert/notification"
	"github.com/target/goalert/notificationchannel"
	"github.com/target/goalert/oncall"
	"github.com/target/goalert/schedule"
	"github.com/target/goalert/user"
	"github.com/target/goalert/user/contactmethod"
)

// Config contains parameters for controlling how the Engine operates.
type Config struct {
	AlertLogStore       alertlog.Store
	AlertStore          alert.Store
	ContactMethodStore  contactmethod.Store
	NotificationManager *notification.Manager
	UserStore           *user.Store
	NotificationStore   notification.Store
	NCStore             notificationchannel.Store
	OnCallStore         oncall.Store
	ScheduleStore       *schedule.Store

	ConfigSource config.Source

	Keys keyring.Keys

	MaxMessages int

	DisableCycle bool
}
