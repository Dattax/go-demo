package main

import "github.com/99designs/gqlgen/cmd"

func main() {
	cmd.Execute()
}
